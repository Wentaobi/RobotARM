/*          PWM and Timer
    PWM1   = pin 20 in H1    PWM output
    PWM0   = pin 21 in H1    PWM output
    PT2    = pin 11 in H1    connected to Encoders' output
    PT1    = pin 12 in H1    connected to Encoders' output
*/

#include <stdio.h>
#include <hidef.h>      /* common defines and macros */
#include "derivative.h"      /* derivative-specific definitions */

#include <stdlib.h>

#define uint unsigned int
#define uchar unsigned char

  #define BIT0 0x01       /* easier to assign pins this way*/
  #define BIT1 0x02
  #define BIT2 0x04
  #define BIT3 0x08
  #define BIT4 0x10
  #define BIT5 0x20
  #define BIT6 0x40
  #define BIT7 0x80

#define Delay_1US 8000000/30000  

#define SPI 

#define PIXY_ARRAYSIZE              100
#define PIXY_START_WORD             0xaa55
#define PIXY_START_WORD_CC          0xaa56
#define PIXY_START_WORDX            0x55aa
#define PIXY_SERVO_SYNC             0xff
#define PIXY_CAM_BRIGHTNESS_SYNC    0xfe
#define PIXY_LED_SYNC               0xfd
#define PIXY_OUTBUF_SIZE            64

#define PIXY_SYNC_BYTE              0x5a
#define PIXY_SYNC_BYTE_DATA         0x5b
#define uint16_t                    unsigned int 
#define uint8_t                     unsigned char

unsigned short EC_Period[20]; // resolution = 1us
unsigned short EC_Count;  // number of measurements
unsigned short EC_Period1[20]; // resolution = 1us
unsigned short EC_Count1;  // number of measurements
unsigned short Last;   // time of previous edge
unsigned short Last1;   // time of previous edge
float Tl,Tr;


// the routines
void init();      

int getStart(void);
uint16_t getBlocks(uint16_t maxBlocks);
int setServos(uint16_t s0, uint16_t s1);
int setBrightness(uint8_t brightness);
int setLED(uint8_t r, uint8_t g, uint8_t b);

int ATD0=0,ATD1=0,ATD2=0;
int position_x,sig;
unsigned short int k ; 

int xset=512,yset=235,zset=210,hset=50;   

// data types
typedef enum 
{
    NORMAL_BLOCK,
    CC_BLOCK // color code block
} BlockType;

typedef struct  
{
  uint16_t signature; 
  uint16_t x;
  uint16_t y;
  uint16_t width;
  uint16_t height;
  uint16_t angle; // angle is only available for color coded blocks
} Block;

// communication routines
static uint16_t getWord(void);
static int send(uint8_t *data, int len);

#ifndef SPI //////////// for I2C and UART   

extern uint8_t getByte(void);
extern int sendByte(uint8_t byte);

uint16_t getWord(void)
{
  // this routine assumes little endian 
  uint16_t w; 
  uint8_t c;
  c = getByte();
  w = getByte();
  w <<= 8;
  w |= c; 
  return w;
}

int send(uint8_t *data, int len)
{
  int i;
  for (i=0; i<len; i++)
    sendByte(data[i]);

  return len;
}

#else ///////////// SPI routines

// SPI sends as it receives so we need a getByte routine that 
// takes an output data argument
extern uint8_t getByte(uint8_t out); 

// variables for a little circular queue
static uint8_t g_outBuf[PIXY_OUTBUF_SIZE];
static uint8_t g_outLen = 0;
static uint8_t g_outWriteIndex = 0;
static uint8_t g_outReadIndex = 0;

uint16_t getWord()
{
  // ordering is big endian because Pixy is sending 16 bits through SPI 
  uint16_t w;
  uint8_t c, cout = 0;

  if (g_outLen)
  {
    w = getByte(PIXY_SYNC_BYTE_DATA);
    cout = g_outBuf[g_outReadIndex++];
    g_outLen--;
    if (g_outReadIndex==PIXY_OUTBUF_SIZE)
      g_outReadIndex = 0; 
  }
  else
    w = getByte(PIXY_SYNC_BYTE); // send out sync byte
  w <<= 8;
  c = getByte(cout); // send out data byte
  w |= c;

  return w;
}

int send(uint8_t *data, int len)
{
  int i;

  // check to see if we have enough space in our circular queue
  if (g_outLen+len>PIXY_OUTBUF_SIZE)
    return -1;

  g_outLen += len;
  for (i=0; i<len; i++)
  {
    g_outBuf[g_outWriteIndex++] = data[i];
    if (g_outWriteIndex==PIXY_OUTBUF_SIZE)
      g_outWriteIndex = 0;
  }
  return len;
}

#endif //////////////// end SPI routines

static int g_skipStart = 0;
static BlockType g_blockType;
static Block *g_blocks;

void init()
{
  g_blocks = (Block *)malloc(sizeof(Block)*PIXY_ARRAYSIZE);
}

int getStart(void)
{
  uint16_t w, lastw;
                                               
  lastw = 0xffff;

  while(1)
  {
    w = getWord();
    if (w==0 && lastw==0)
      return 0; // no start code  
    else if (w==PIXY_START_WORD && lastw==PIXY_START_WORD)
    {
      g_blockType = NORMAL_BLOCK;
      return 1; // code found!
    }
    else if (w==PIXY_START_WORD_CC && lastw==PIXY_START_WORD)
    {
      g_blockType = CC_BLOCK; // found color code block
      return 1;
    }    
    else if (w==PIXY_START_WORDX) 
#ifdef SPI
      getByte(0); // we're out of sync! (backwards)
#else
      getByte(); // we're out of sync! (backwards)
#endif
    lastw = w; 
  }
}

uint16_t getBlocks(uint16_t maxBlocks)
{
  uint8_t i;
  uint16_t w, blockCount, checksum, sum;
  Block *block;

  if (!g_skipStart)
  {
    if (getStart()==0)
      return 0;
  }
  else
    g_skipStart = 0;

  for(blockCount=0; blockCount<maxBlocks && blockCount<PIXY_ARRAYSIZE;)
  {
    checksum = getWord();
    if (checksum==PIXY_START_WORD) // we've reached the beginning of the next frame
    {
      g_skipStart = 1;
      g_blockType = NORMAL_BLOCK;
      return blockCount;
    }
    else if (checksum==PIXY_START_WORD_CC)
    {
      g_skipStart = 1;
      g_blockType = CC_BLOCK;
      return blockCount;
    }
    else if (checksum==0)
      return blockCount;

    block = g_blocks + blockCount;

    for (i=0, sum=0; i<sizeof(Block)/sizeof(uint16_t); i++)
    {
      if (g_blockType==NORMAL_BLOCK && i>=5) // no angle for normal block
      {
        block->angle = 0;
        break;
      }
      w = getWord();
      sum += w;
      *((uint16_t *)block + i) = w;
    }

    // check checksum
    if (checksum==sum)
      blockCount++;
    else
      printf("checksum error!\n");

    w = getWord();
    if (w==PIXY_START_WORD)
      g_blockType = NORMAL_BLOCK;
    else if (w==PIXY_START_WORD_CC)
      g_blockType = CC_BLOCK;
    else
      return blockCount;
  }
}

int setServos(uint16_t s0, uint16_t s1)
{
  uint8_t outBuf[6];

  outBuf[0] = 0x00;
  outBuf[1] = PIXY_SERVO_SYNC; 
  *(uint16_t *)(outBuf + 2) = s0;
  *(uint16_t *)(outBuf + 4) = s1;

  return send(outBuf, 6);
}

int setBrightness(uint8_t brightness)
{
  uint8_t outBuf[3];

  outBuf[0] = 0x00;
  outBuf[1] = PIXY_CAM_BRIGHTNESS_SYNC; 
  outBuf[2] = brightness;

  return send(outBuf, 3);                            //
}

int setLED(uint8_t r, uint8_t g, uint8_t b)
{
  uint8_t outBuf[5];

  outBuf[0] = 0x00;
  outBuf[1] = PIXY_LED_SYNC; 
  outBuf[2] = r;
  outBuf[3] = g;
  outBuf[4] = b;

  return send(outBuf, 5);
}                                            
//**copy from the website end from here**  

//*SPI intitialize 

void SPI_set(void){  //this routine is for setting the three registers of SPI
  SPI0CR1 = 0x50;
  SPI0CR2 = 0x00;   //regular mode
  SPI0BR  = 0x02;   //4 MHz
//  SPI0BR  = 0x04;  
}
                                          
uint8_t getByte(unsigned char code){    
unsigned char datareceived;
  while(((SPI0SR&0x20)==0)){};
  SPI0DR = code;
  while(((SPI0SR&0x80)==0)){};
  datareceived = SPI0DR;
  return datareceived;

}                               

void SPIsend(unsigned char code) {
  uchar dummy;
  while((SPI0SR&0x20)==0);
  SPI0DR=code;
  while((SPI0SR&0x80)==0);
  dummy=SPI0DR ;
  printf("data=%u\r\n",dummy);
}

void delay(uint num);

 int abc=0;
 uint speed=0,speed2=0,final=0;

static void SCI0Init(void) {
  SCI0BDL = (unsigned char)((16000000UL /* OSC freq */ / 2) / 38400 /* baud rate */ / 16 /*factor*/); 
  SCI0CR2 = 0x2C;
}

 void TERMIO_PutChar(char C)
         { 
               while(!(SCI0SR1&0x80)) ;         //keep waiting when not empty  
               SCI0DRL=C;
         }

 void putcharSCI0 (char data) 
{
 	while (!(SCI0SR1&SCI0SR1_TDRE_MASK)) //check TXbuffer is ready or not,TDRE
  	; //OSTimeDly(1); /* wait here */
  	SCI0DRL=data; //put the char in the TX
}

 void SendFrame(int x,uint16_t y,uint16_t z,uint16_t h)   //define the command frame that is used to control the next pose of abotix 
{
  
  unsigned char sum, invertedChecksum, checksum;
  
  uint8_t xHighByte=0,xLowByte=0,yHighByte=0,yLowByte=0,zHighByte=0,zLowByte=0,wristAngleHighByte=0,wristAngleLowByte=60,
  
  wristRotateHighByte=2,wristRotateLowByte=0,gripperHighByte=0,gripperLowByte=0,deltaValBytes=128,buttonByte=0,extValBytes=0;
     
  xLowByte=x;
  xHighByte=x>>8;
  yLowByte=y;
  yHighByte=y>>8;
  zLowByte=z;
  zHighByte=z>>8;
  gripperLowByte=h;
  gripperHighByte=h>>8;
  
  // printf("xh=%5.0u   xl=%5.0u   yh=%5.0u   yl=%5.0u  zh=%5.0u   zl=%5.0u   \r\n",xHighByte,xLowByte,yHighByte,yLowByte,zHighByte,zLowByte);


  sum = xHighByte + xLowByte +  yHighByte + yLowByte +  zHighByte + zLowByte +  wristAngleHighByte + wristAngleLowByte +  wristRotateHighByte + wristRotateLowByte +  gripperHighByte + gripperLowByte + deltaValBytes + buttonByte + extValBytes;//add up bytes 2-16
	invertedChecksum = sum % 256;//isolate the lowest byte
	checksum = 255 - invertedChecksum; //invert value to get file checksum

	putcharSCI0(0xff);
  putcharSCI0(xHighByte);
	putcharSCI0(xLowByte);
 	putcharSCI0(yHighByte);
	putcharSCI0(yLowByte);
	putcharSCI0(zHighByte);
 	putcharSCI0(zLowByte);
	putcharSCI0(wristAngleHighByte);
 	putcharSCI0(wristAngleLowByte);
 	putcharSCI0(wristRotateHighByte);
 	putcharSCI0(wristRotateLowByte);
 	putcharSCI0(gripperHighByte);
 	putcharSCI0(gripperLowByte);
 	putcharSCI0(deltaValBytes);
 	putcharSCI0(buttonByte);
	putcharSCI0(extValBytes);
  putcharSCI0(checksum);
   
}
  
void PWM_Init(void)
 {

    PWMPOL=0x20;
    PWMCLK=0x00;
    PWMPRCLK=0x04;
    PWMCAE=0x00;
    PWMCTL=0x00;
    PWMPER0=250;
    PWMPER1=250;
    PWMDTY0=125; 
    PWMDTY1=125;
    PWME=0xFF; /* enable pwm */
    
}

void EC_Init(void){  
  asm sei           // make atomic
  DDRT &= ~0x06;  // PT2 input
  TCTL4 |= 0x28;  // falling edge IC2
  TIE |= 0x06;     // Arm IC2
  EC_Count = 0;  
  Last = TCNT;     // first measurement wrong
  Last1 = TCNT;     // first measurement wrong
  TIOS &= ~0x06;   // PT2 input capture
  asm cli
  TSCR1 = 0x80;   // enable TCNT, 1us
  TSCR2 = 0x02;   // divide by 4 TCNT prescale, TOI disarm
  PACTL = 0;      // timer prescale used for TCNT
}

	float setspeedl,setspeedr;
	float actualspeedl,actualspeedr;
	float errl,errr;
	float errl_next,errr_next;
	float errl_last,errr_last;
	float kp,ki,kd;
	float incrementspeedl,incrementspeedr;


void PID_init(void)
{
	   setspeedl=0.0;
	   actualspeedl=0.0;
	   errl=0.0;
  	 errl_next=0.0;
  	 errl_last=0.0;
   	 setspeedr=0.0;
	   actualspeedr=0.0;
	   errr=0.0;
   	 errr_next=0.0;
  	 errr_last=0.0;
  	 	kp=0.1;
  	ki=0.05;
  	kd=0.005;
}

float PID_control_left(float speed)
{
	  setspeedl=speed;
	  errl=setspeedl-actualspeedl;

  	incrementspeedl=kp*(errl-errl_next)+ki*errl+kd*(errl-2*errl_next+errl_last);
  	actualspeedl+=incrementspeedl;
  	errl_last=errl_next;
  	errl_next=errl;
  	if(actualspeedl>0.8) {
	  actualspeedl=0.8;}
	  return actualspeedl;
}
float PID_control_right(float speed)
{
	  setspeedr=speed;
	  errr=setspeedr-actualspeedr;

	  incrementspeedr=kp*(errr-errr_next)+ki*errr+kd*(errr-2*errr_next+errr_last);
	  actualspeedr+=incrementspeedr;
  	  errr_last=errr_next;
	  errr_next=errr;
		if(actualspeedr>0.8) {
	  actualspeedr=0.8;}
	  return actualspeedr;
}

void ATD_set(void) {
  ATD0CTL2 = 0x80;
  ATD0CTL3 = 0x18;
  ATD0CTL4 = 0x63;//the used one is 00
  ATD0CTL5 = 0xb5;
}



void search (void){

    k=rand()%3;
    switch (k){
    case 0:  PWMDTY0 = 115;
             PWMDTY1 = 115;
            break;
            
    case 1:  PWMDTY0 = 125;
             PWMDTY1 = 115;	//change 80 to 103
	     actualspeedl=PID_control_left(0.4);
             PWMDTY1=103-(actualspeedl-0.4)*10;

            break;
            
    case 2:  PWMDTY0 = 115;
            PWMDTY1 = 125;
            break;
            
  }
 }


 void circle (void){
                 
    PWMDTY0 = 125;
    PWMDTY1 = 103;
    actualspeedl=PID_control_left(0.4);
    PWMDTY1=103+(actualspeedl-0.4)*5;
     if (position_x == 160){
       PWMDTY0 = 125;
       PWMDTY1 = 125;  

    }
}


  void avoid(void)
 {  int i ;
  
  
      
  
        if ((ATD0<65)&(ATD1>64)&(ATD2>73)){
      i=1 ;
      } 
        if ((ATD0<65)&(ATD1<64)&(ATD2>73)){
      i=1 ;
      } 
        if ((ATD0>65)&(ATD1>64)&(ATD2<73)){
      i=2 ;
      } 
        if ((ATD0>65)&(ATD1<64)&(ATD2<73)){
      i=2 ;
      } 
        if ((ATD0<65)&(ATD1<64)&(ATD2<73)){
      i=3 ;
      }
        if ((ATD0<65)&(ATD1>64)&(ATD2<73)){
      i=3 ;
      }
        if ((ATD0>65)&(ATD1<64)&(ATD2>73)){
      i=3 ;
      }
      
 
 switch (i){
      case 1: PWMDTY0 = 115;//��ת                      
              PWMDTY1 = 145;
		actualspeedr=PID_control_right(0.4);
   		PWMDTY0=103+(actualspeedr-0.4)*5;
              i=0;
              break;
    
      case 2:  PWMDTY0 = 145; //��ת                     
               PWMDTY1 = 115;
		actualspeedl=PID_control_left(0.4);
    		PWMDTY1=103+(actualspeedl-0.4)*5;
		
              i=0;
              break;
              
      case 3:  PWMDTY0 = 140; //����  CHANGE FROM 155 TO 140                    
               PWMDTY1 = 140;
		actualspeedr=PID_control_right(0.4);
   		PWMDTY0=140-(actualspeedr-0.4)*5;
		actualspeedl=PID_control_left(0.4);
   		PWMDTY1=140-(actualspeedl-0.4)*5;
              i=0;
              break;
              
     default: break;
    }
 }



void follow(void)
{
      getBlocks(1);

            position_x=(*g_blocks).x;
            
            
    if (position_x < 155){                 
        PWMDTY0 = 105;                      
        PWMDTY1 = 125;
          if((*g_blocks).width>50){
           PWMDTY0 = 125;        
           PWMDTY1 = 125;
         }
     }

    if (position_x > 165){
        PWMDTY0 = 125;                      
        PWMDTY1 = 105;
          if((*g_blocks).width>50){
           PWMDTY0 = 125;        
           PWMDTY1 = 125;
         }
     }
    if (position_x>155&&position_x<165){
        PWMDTY0 = 105;                      
        PWMDTY1 = 105;
	actualspeedl=PID_control_left(0.4);
   	PWMDTY1=103+(actualspeedl-0.4)*5;
	actualspeedr=PID_control_right(0.4);
   	PWMDTY0=103+(actualspeedr-0.4)*5;
         if((*g_blocks).width>50){
           PWMDTY0 = 125;        
           PWMDTY1 = 125;
         }
     }
    
}
/*
void pickup(void) {
        delay(2000); 
      SendFrame(xset,320,240,180);
      
      delay(2000);
      SendFrame(xset,320,110,180);
      
      delay(2000);
      SendFrame(xset,320,110,400);

      delay(2000);
      SendFrame(xset,320,240,400);
      
      delay(2000);
      SendFrame(xset,100,240,400);
      
      delay(2000);
      SendFrame(xset,100,240,400);

      delay(2000);
      SendFrame(xset,320,240,400);
      
      delay(2000);
      SendFrame(xset,320,110,400);
      
      delay(2000);
      SendFrame(xset,320,100,180);       
      
      delay(1000);
} */



void pickup(void) {
        delay(2000); 
      SendFrame(xset,320,240,180);
      
      delay(2000);
      SendFrame(xset,320,50,180);
      
      delay(2000);
      SendFrame(xset,320,50,400);

      delay(2000);
      SendFrame(xset,320,240,400);
      
      delay(2000);
      SendFrame(xset,90,240,400);
      
      delay(2000);
      SendFrame(xset,90,240,400);

      delay(2000);
      SendFrame(xset,320,240,400);
      
      delay(2000);
      SendFrame(xset,320,50,400);
      
      delay(2000);
      SendFrame(xset,320,50,180);       
      
      delay(2000);
      
      SendFrame(xset,320,240,180);
      
      delay(2000);
      SendFrame(xset,90,240,400);
      
      
}



void main(void) {
 int blk;
 int xsett;    

  srand(3);

  ATD_set();

 DDRB=0xff;
 //DDRT=0x0;
 DDRP=0xff;
 DDRA=0xff;
 
 PORTA=0x00;
 delay(300);
 PORTA=0xff;
 delay(300);
 DDRA=0x00;
 PORTA=0x00;
 delay(300);
 






    SCI0Init();
   
    SPI_set(); 
    
    init();
    EC_Init(); // start measuring Encoders' period 
    PWM_Init();
    PID_init();
    EnableInterrupts;

  putcharSCI0(0xff);
  putcharSCI0(0);
	putcharSCI0(0);
 	putcharSCI0(0);
	putcharSCI0(0);
	putcharSCI0(0);
 	putcharSCI0(0);
	putcharSCI0(0);
 	putcharSCI0(0);
 	putcharSCI0(0);
 	putcharSCI0(0);
 	putcharSCI0(0);
 	putcharSCI0(0);
 	putcharSCI0(0);
 	putcharSCI0(0);
	putcharSCI0(0x20);
  putcharSCI0(0xdf);     
     
    while(0){
     
      delay(2000); 
      SendFrame(512,320,250,180)
      ;
      delay(2000);
      SendFrame(512,320,100,180);
      
      delay(2000);
      SendFrame(512,320,100,400);

      delay(2000);
      SendFrame(512,320,250,400);
      
      delay(2000);
      SendFrame(512,100,250,400);
      
      delay(2000);
      SendFrame(512,100,250,400);

      delay(2000);
      SendFrame(512,320,250,400);
      
      delay(2000);
      SendFrame(512,320,100,400);
      
      delay(2000);
      SendFrame(512,320,100,180);
            }
 //  printf("blk= \r\n");
   
 //  printf("blk= \r\n");   
      
  for(;;) {  
       // while(ATD0STAT0_SCF == 1 ) {
        ATD0=ATD0DR0;
        ATD1=ATD0DR1;
        ATD2=ATD0DR2;
        
        printf("data=%3.0u  data=%3.0u data=%3.0u    data=%3.0u data=%3.0u   \r\n",ATD0,ATD1,ATD2,PWMDTY0,PWMDTY1);
        
       // }

      blk=getBlocks(1);        
      
       while(0) {
           blk=getBlocks(1);
        ATD0=ATD0DR0;
        ATD1=ATD0DR1;
        ATD2=ATD0DR2;
           search();
           avoid();
            printf("data=%3.0u  data=%3.0u data=%3.0u    data=%3.0u data=%3.0u   blk=%1.0u\r\n",ATD0,ATD1,ATD2,PWMDTY0,PWMDTY1,blk);
                       
          } 
      
        while(blk==0){
      
        blk=getBlocks(1);
      
        ATD0=ATD0DR0+30;
        ATD1=ATD0DR1+30;
        ATD2=ATD0DR2+30;
        delay(100);   
           search();
           avoid();
           delay(100); 
            printf("data=%3.0u  data=%3.0u data=%3.0u    data=%3.0u data=%3.0u blk=%3.0u  \r\n",ATD0,ATD1,ATD2,PWMDTY0,PWMDTY1,blk);
             
           //search();
          }

     //   printf("blk= \r\n");
     //   printf("s2=%2.0u   x2=%5.0u   y2=%5.0u   width2=%5.0u   height2=%5.0u  \r\n\r\n",(*(g_blocks+1)).signature,(*(g_blocks+1)).x,(*(g_blocks+1)).y,(*(g_blocks+1)).width,(*(g_blocks+1)).height);
 
       blk=getBlocks(1);
      if((*g_blocks).width<60){
      
      position_x=(*g_blocks).x;
        
      while(1){
      
        ATD0=ATD0DR0+30;
        ATD1=ATD0DR1+30;
        ATD2=ATD0DR2+30;
        blk=getBlocks(1);
        
        Tl=EC_Period[10];
        actualspeedl=20944/Tl;
 	Tr=EC_Period1[10];
   	actualspeedr=20944/Tr;
          
          position_x=(*g_blocks).x;    
                    
          follow();
           if((*g_blocks).width<15) {
            avoid();
          
         // delay(100);
          } 
          
          if((*g_blocks).width>50) {
           break;
          } 
          
          
          
                    
          printf("ATD0=%3.0u  ATD0=%3.0u  ATD0=%3.0u   s=%2.0u   x=%5.0u   y=%5.0u   width=%5.0u   height=%5.0u     PWMDTY0=%5.0u    PWMDTY1=%5.0u\r\n",ATD0,ATD1,ATD2,(*g_blocks).signature,(*g_blocks).x,(*g_blocks).y,(*g_blocks).width,(*g_blocks).height,PWMDTY0,PWMDTY1);
        }
 
 
 
      
     xset=(*g_blocks).x;
      
     xsett=512+(xset-160); 
     xset=xsett;
     
      
      if(xset>602)
      xset=602;
      if(xset<422)
      xset=422;
      
      if(yset>300)
      yset=300;
      if(yset<100)
      yset=100;
      
      if(zset>200)
      zset=200;
      if(zset<50)
      zset=50;
      
      pickup();
    
    while(1){
              PWMDTY0 = 125;//��ת                      
              PWMDTY1 = 125;
      
        blk=getBlocks(1);
        printf("�Ѽ��Ŀ��  xset=%4.0u   xsett=%5.0u   s=%2.0u   x=%5.0u   y=%5.0u   width=%5.0u   height=%5.0u\r\n",xset,xsett,(*g_blocks).signature,(*g_blocks).x,(*g_blocks).y,(*g_blocks).width,(*g_blocks).height);
    }
      }
 
 
 //  printf("data=%d\r\n",getByte()); 
      
  } /* loop forever */
  /* please make sure that you never leave main */
}

void delay(uint num)
{ 
  unsigned long int i; 

  while (num > 0)
      {
        i = Delay_1US;
        //i = 1333;
            while (i > 0)
                {
                  i = i - 1; 
                }
        num = num - 1;
      }
} 

#pragma CODE_SEG __NEAR_SEG NON_BANKED
void interrupt VectorNumber_Vsci0 SCI0_ISR(void){
//  unsigned char rc;
//  rc = SCI0SR1; /* dummy read to clear flags */
//  rc = SCI0DRL; /* data read */
//  abc=printf("rc=%c \r\n",rc);
//  SCI0DRL = rc;
}
 
#pragma CODE_SEG __NEAR_SEG NON_BANKED
void interrupt 10 EC2Handle(void){ 
  TFLG1 |= 0x04;     // clear C2F
  EC_Period[EC_Count] = TC2-Last;
  Last = TC2;
  if(EC_Count<19){
    EC_Count ++;
  }
  
   else {
    EC_Count=0;
  }
}

#pragma CODE_SEG __NEAR_SEG NON_BANKED
void interrupt 9 EC1Handle(void){ 
  TFLG1 |= 0x02;     // clear C1F
  EC_Period1[EC_Count1] = TC1-Last1;
  Last1 = TC1;
  if(EC_Count1<19){
    EC_Count1 ++;
  } 
  else {
    EC_Count1=0;
  }
}







